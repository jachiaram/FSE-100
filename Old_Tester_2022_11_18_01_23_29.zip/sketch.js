var screen = 0;
var button1;
var button2;
var button3;
var distance;

var back1;

var submitText;
var inputText;

var sample = "";
var words;
var endScreen;
var t;
var s;
var showText = false;
var correct = 0;
var percent = 0;
var cps = "?";
var spent;

this.x = getRandomInt(250);
this.y = getRandomInt(250);
let locked1 = false;
let locked2 = false;
let over2 = false;
let over1 = false;
var score = 0;

let counter = 0;
let fr = 60;
let seconds = 0.0;

let squareX = 350;
let squareY = 42;
let squareSL = 25;
let circleX = 650;
let circleY = 50;
let circleR = 25;
let ovalX = 165;
let ovalY = 250;
let ovalW = 25;
let ovalH = 50;

let sq;
let circle1;
let oval;

function setup() {
  switch (screen) {
    case 0:
      createCanvas(400, 400);
      background("rgb(99, 37, 209)");
      textSize(50);
      fill(14, 241, 19);
      text("Old Tester", 85, 100);

      button1 = createButton("Fruit Ninja");
      button1.show();
      distance = width / 5 / 2 - button1.width / 3 / 2;
      button1.position(distance, height / 2 - button1.height / 2);
      button1.style("background-color", "#9B2EAD");
      button1.style("color", "rgb(14, 241, 19)");
      button1.style("border-radius", "8px");
      button1.style("size", "40px");
      button1.style("box-shadow", "0 3px 5px rgba(0, 0, 0, 0.18)");
      button1.size(100, 100);

      button2 = createButton("Typing Test");
      button2.show();
      button2.position(
        width / 2.1 - button2.width / 2,
        height / 2 - button2.height / 2
      );
      button2.style("background-color", "#9B2EAD");
      button2.style("color", "rgb(14, 241, 19)");
      button2.style("border-radius", "8px");
      button2.style("size", "40px");
      button2.style("box-shadow", "0 3px 5px rgba(0, 0, 0, 0.18)");
      button2.size(100, 100);

      //button three creation and positioning
      button3 = createButton("Shape Sorter");
      button3.show();
      button3.position(10 * distance, height / 2 - button3.height / 2);

      //styling for button three
      button3.style("background-color", "#9B2EAD");
      button3.style("color", "rgb(14, 241, 19)");
      button3.style("border-radius", "8px");
      button3.style("size", "40px");
      button3.style("box-shadow", "0 3px 5px rgba(0, 0, 0, 0.18)");
      button3.size(100, 100);

      back1 = createButton("Back");
      back1.style("background-color", "#9B2EAD");
      back1.style("color", "rgb(14, 241, 19)");
      back1.style("border-radius", "8px");
      back1.style("size", "40px");
      back1.style("box-shadow", "0 3px 5px rgba(0, 0, 0, 0.18)");
      back1.hide();

      inputText = createInput().attribute("maxlength", sample.length);
      inputText.position(100, 250);
      inputText.hide();

      submitText = createButton("submit");
      submitText.position(100 + inputText.width, 250);
      submitText.mousePressed(submit);
      submitText.hide();

      //button functionality
      button1.mousePressed(activityOne);
      button2.mousePressed(activityTwo);
      button3.mousePressed(activityThree);
      break;
    case 1:
      button1.hide();
      button2.hide();
      button3.hide();

      createCanvas(400, 400);
      background("rgb(99, 37, 209)");

      textSize(50);
      fill(14, 241, 19);
      text("Fruit Ninja", 90, 100);

      // back1 = createButton('Back');
      back1.style("background-color", "#9B2EAD");
      back1.style("color", "rgb(14, 241, 19)");
      back1.style("border-radius", "8px");
      back1.style("size", "40px");
      back1.style("box-shadow", "0 3px 5px rgba(0, 0, 0, 0.18)");

      distance = width / 5 / 2 - button1.width / 3 / 2;
      back1.position(distance - 20, height / 8 - back1.height / 0.75);
      back1.hide();
      back1.mousePressed(return1);
      time = 10;
      break;
    case 2:
      button1.hide();
      button2.hide();
      button3.hide();

      sample = "";
      clear();

      createCanvas(400, 400);
      background("#F7EAC3");

      textSize(40);
      fill("black");
      text("Typing Test", 90, 60);

      back1.position(distance - 20, height / 8 - back1.height / 2);
      back1.show();
      back1.mousePressed(return1);

      words = [
        "where",
        "over",
        "if",
        "but",
        "attack",
        "group",
        "jump",
        "run",
        "smelly",
        "water",
        "plant",
        "words",
        "computer",
        "student",
        "me",
        "help",
        "impossible",
        "govern",
        "and",
        "bear",
      ];
      frase();

      inputText = createInput().attribute("maxlength", sample.length);
      inputText.position(100, 250);
      inputText.show();

      submitText.show();

      let c = color("black");
      fill(c);
      textSize(15);
      text(sample, 50, 230);

      if (showText) {
        textSize(20);
        endSceen = text(s, 30, 100);
        drawTyped(135, 100, t);
        fill(c);
        text("Your Score: " + percent + "%", 30, 150);
        fill(c);
      }

      break;
    case 3:
      button1.hide();
      button2.hide();
      button3.hide();

      createCanvas(700, 400);
      background("rgb(99, 37, 209)");

      textSize(50);
      fill(14, 241, 19);
      text("Shape Sorter", 90, 100);

      back1.position(distance - 30, height / 8 - back1.height / 6);
      back1.show();
      back1.mousePressed(return1);
      sq = new myShape(width / 2, height / 2, 25, "square", 0);
      circle1 = new myShape(30, 30, 25, "circle", 0);
      oval = new myShape(650, 350, 25, "oval", 50);
      frameRate(fr);
      break;
    default:
      break;
  }
}

function draw() {
  switch (screen) {
    case 0:
      break;
    case 1:
      loop();
      time = 10 - spent;
      spent++;

      background(102, 51, 0);
      circleAppear();
      textSize(15);
      text(time + " seconds", 15, 365);
      textSize(15);
      text("Score: ", 15, 350);
      textSize(15);
      text(score, 65, 350);
      textSize(30);
      text("Fruit Ninja", 200, 365);

      frameRate(1);
      //timer();
      if (time == 0) {
        noLoop();
        back1.show();
      }

      break;
    case 2:
      break;
    case 3:
      loop();
      background(50, 89, 100);

      square(squareX, squareY, squareSL);
      text("SQUARE", 325, 100);
      ellipse(circleX, circleY, circleR, circleR);
      text("CIRCLE", 630, 100);
      ellipse(ovalX, ovalY, ovalW, ovalH);
      text("OVAL", 150, 320);

      sq.move();
      circle1.move();
      oval.move();

      sq.display();
      circle1.display();
      oval.display();

      showTimer();
      break;
    default:
      break;
  }
}

function return1() {
  clear();
  back1.hide();
  inputText.hide();
  submitText.hide();
  screen = 0;
  spent = 0;
  time = 10;
  setup();
}

function activityOne() {
  clear();
  screen = 1;
  setup();
  spent = 0;
  score = 0;
  draw();
}

function activityTwo() {
  clear();
  screen = 2;
  showText = false;
  setup();
}

function activityThree() {
  clear();
  screen = 3;
  seconds = 0.0;
  counter = 0;
  setup();
  draw();
}

function submit() {
  correct = 0;
  const typed = inputText.value();
  t = [["", ""]];
  s = "You typed : ";
  for (var i = 0; i < sample.length; i++) {
    if (typed.charAt(i) == sample.charAt(i)) {
      t[i] = [typed.charAt(i), color("green")];
      correct++;
    } else {
      t[i] = [typed.charAt(i), color("red")];
    }
  }
  showText = true;
  percent = Math.floor((correct / sample.length) * 100);
  let c = color("black");
  if (showText) {
    textSize(20);
    endSceen = text(s, 30, 150);
    drawTyped(135, 150, t);
    fill(c);
    text("Your Score: " + percent + "%", 30, 200);
    fill(c);
  }
  submitText.hide();
  text("Go back to home to try again", 30, 350);
}

function drawTyped(x, y, text_array) {
  var pos_x = x;
  for (var i = 0; i < text_array.length; ++i) {
    var part = text_array[i];
    var t = part[0];
    var c = part[1];
    var w = textWidth(t);
    fill(c);
    text(t, pos_x, y);
    pos_x += w;
  }
}

function frase() {
  for (var i = 0; i < 5; i++) {
    var index = getRandomInt(20);
    if (i == 4) {
      sample += words[index];
    } else {
      sample += words[index] + " ";
    }
  }
}

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

function bombAndFruit() {
  this.x = getRandomInt(250);
  this.y = getRandomInt(250);
  let b = color(204, 0, 0);
  fill(b);
  circle(this.x, this.y, 100);

  let f = color(153, 255, 153);
  fill(f);
  circle(this.x, this.y, 50);
}
function clicked() {
  var d = dist(mouseX, mouseY, this.x, this.y);
  // mouseIsOverBox = true;
  over1 = true;
  if (!locked1 && d < 25) {
    // make stroke white and fill pink
    fill(255, 255, 100);
    circle(this.x, this.y, 50);

    score++;
  } else if (d < 50 && d > 25) {
    score--;
  }
}

function circleAppear() {
  let s = second();

  if (getRandomInt(10) <= 10) {
    bombAndFruit();
  }
}

function timer() {
  if (time > 10) {
    noLoop();
  }
}

function mousePressed() {
  if (screen == 1) {
    clicked();
  } else if (screen == 3) {
    sq.clicked();
    circle1.clicked();
    oval.clicked();
  }
}

function mouseReleased() {
  if (screen == 3) {
    sq.released();
    circle1.released();
    oval.released();
  }
}

function mouseDragged() {
  if (screen == 3) {
    sq.pulled();
    circle1.pulled();
    oval.pulled();
  }
}

class myShape {
  constructor(a, b, radius, given, height) {
    this.type = given;
    this.x = a;
    this.y = b;
    this.r = radius;
    this.h = height;
    this.col = color(50, 89, 100);
    this.line = color(255);
    this.over = false;
    this.locked = false;
    this.xOffset = 0.0;
    this.yOffset = 0.0;

    rectMode(RADIUS);
    strokeWeight(2);
    stroke(this.line);
    fill(this.col);
  }

  move() {
    if (
      // square(350, 42, 25);
      ((this.type == "square" &&
        abs(squareX - this.x) < this.r / 7 &&
        abs(this.y - squareY) < this.r / 7) ||
        // circle(650, 50, 50, 50);
        (this.type == "circle" &&
          abs(circleX - this.x) < this.r / 7 &&
          abs(this.y - circleY) < this.r / 7) ||
        // oval(650, 250, 50, 75);
        (this.type == "oval" &&
          abs(ovalX - this.x) < this.r / 8 &&
          abs(this.y - ovalY) < this.h / 8)) &&
      this.locked
    ) {
      this.line = color(0, 255, 0);
      this.col = color(0, 255, 0);
      this.snap();
      this.over = false;
      this.locked = false;
      counter++;
    }

    if (
      mouseX > this.x - this.r &&
      mouseX < this.x + this.r &&
      mouseY > this.y - this.r &&
      mouseY < this.y + this.r
    ) {
      this.over = true;
      if (!this.locked) {
        this.col = color(255);
      }
    } else {
      this.col = color(50, 89, 100);
      this.over = false;
    }
  }

  clicked() {
    if (this.over) {
      this.locked = true;
      this.col = color(255);
    } else {
      this.locked = false;
    }
    this.xOffset = mouseX - this.x;
    this.yOffset = mouseY - this.y;
  }

  pulled() {
    if (this.locked) {
      this.x = mouseX - this.xOffset;
      this.y = mouseY - this.yOffset;
    }
  }

  released() {
    this.locked = false;
  }

  display() {
    stroke(this.line);
    fill(this.col);
    if (this.type == "square") {
      rect(this.x, this.y, this.r, this.r);
    } else if (this.type == "circle") {
      ellipse(this.x, this.y, this.r, this.r);
    } else {
      ellipse(this.x, this.y, this.r, this.h);
    }
    stroke(255);
    fill(50, 89, 100);
  }

  snap() {
    if (this.type == "oval") {
      this.x = ovalX;
      this.y = ovalY;
    } else {
      if (this.type == "square") {
        this.x = squareX;
        this.y = squareY;
      } else {
        this.x = circleX;
        this.y = circleY;
      }
    }
  }
}

function showTimer() {
  textSize(32);
  text(counter, 350, 350);
  text(round(seconds), 350, 300);

  if (round(seconds) == 1) {
    text("second", 375, 300);
  } else if (round(seconds) < 10) {
    text("seconds", 375, 300);
  } else if (round(seconds) < 100) {
    text("seconds", 395, 300);
  } else {
    text("seconds", 415, 300);
  }

  textSize(12);
  if (counter != 3) {
    seconds += 1 / 60;
  } // ELSE SHOW HOME BUTTON
}
